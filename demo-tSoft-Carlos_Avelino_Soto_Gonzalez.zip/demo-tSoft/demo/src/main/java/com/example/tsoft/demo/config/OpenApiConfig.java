package com.example.tsoft.demo.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI petApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("Pet API")
                        .version("1.0")
                        .description("API para consultar y crear mascotas"));
    }
}